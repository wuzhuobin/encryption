Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices


<Assembly: AssemblyTitle("")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("")> 
<Assembly: AssemblyProduct("")> 
<Assembly: AssemblyCopyright("")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: CLSCompliant(True)> 


<Assembly: Guid("A9194201-C220-4460-B132-EB97A8F5193C")> 


<Assembly: AssemblyVersion("1.0.*")> 
